#if DEBUG && canImport(SwiftUI)
import SwiftUI

@available(iOS 15.0, *)
struct _DevRoot: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
#endif
